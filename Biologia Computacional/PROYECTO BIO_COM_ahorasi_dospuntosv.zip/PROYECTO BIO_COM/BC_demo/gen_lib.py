import os
os.system('ls | grep .fasta > files.txt')
