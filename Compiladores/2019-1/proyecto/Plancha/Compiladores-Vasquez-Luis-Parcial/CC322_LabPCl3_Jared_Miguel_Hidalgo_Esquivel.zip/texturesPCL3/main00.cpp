/*
Computacion Grafica cc322 periodo 2018 II
Fecha 05/10/2018
Alumno: Jared Miguel Hidalgo Esquivel
Archivo: main00.cpp
*/
/*
*Se necesita instalar FreeImage
*sudo apt-get install libfreeimage3 libfreeimage-dev 
* compilar ej:  g++ -Wall -o test main00.cpp -lglut -lGL -lGLU -lfreeimage
*/

#include <iostream>
#include <stdlib.h>
#include <stdlib.h>
#include <GL/glut.h>
#include <FreeImage.h>
#include <assert.h>
#include <fstream>


#define numTEXT 3
GLuint texID[numTEXT];
int angx=0;
int angy=0;

void drawScene();

using namespace std;

////////////////////////////////////////////////////
//Usar las teclas w y x para rotar por el eje x
//y las teclas s y d para rotar por el eje y
////////////////////////////////////////////////////

void handleKeypress(unsigned char key, int x, int y) {
	switch (key) {
		case 27: //Escape key
			exit(0);
		case 'w':
		case 'W':
			angx+=5;
			if(angx>=360) angx=0;
			drawScene();
			break;
		case 'e':
		case 'E':
			angx-=5;
			if(angx<=0) angx=360;
			drawScene();
			break;
		
		case 's':
		case 'S':
			angy+=5;
			if(angy>=360) angy=0;
			drawScene();
			break;
		case 'd':
		case 'D':
			angx-=5;
			if(angy<=0) angy=360;
			drawScene();
			break;
	}
}

 //Cargando Texturas
void loadTextures(const char* name, int n) {
 	glGenTextures(numTEXT,texID);  // Obtener el Id textura .
    void* imgData;      // Puntero a data del Archivo.
    int imgWidth;   // Ancho de Imagen
    int imgHeight;  // Alto.
    FREE_IMAGE_FORMAT format = FreeImage_GetFIFFromFilename(name);
    if (format == FIF_UNKNOWN) {
       printf("Archivo de Imagen desconocido \n");
       }
    FIBITMAP* bitmap = FreeImage_Load(format, name, 0);  //Leer Imagen.
    if (!bitmap) {
        printf("Fallo la carga de imagen \n");
    }
    FIBITMAP* bitmap2 = FreeImage_ConvertTo24Bits(bitmap);  // Convierte a RGB
    FreeImage_Unload(bitmap);
    imgData = FreeImage_GetBits(bitmap2);
    imgWidth = FreeImage_GetWidth(bitmap2);
    imgHeight = FreeImage_GetHeight(bitmap2);
    if (imgData) {
         printf("Textura cargada, tamanio %dx%d\n", imgWidth, imgHeight);
         int format; // Formato del color.
         if ( FI_RGBA_RED == 0 ){
            format = GL_RGB;
		}
         else{
            format = GL_BGR;
            }
		glBindTexture( GL_TEXTURE_2D, texID[n] );  // Cargando textura
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, imgWidth, imgHeight, 0, format,GL_UNSIGNED_BYTE, imgData);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        }
        else {
            printf("Fallo la carga de textura \n");
        }
}

void initRendering() {
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glEnable(GL_NORMALIZE);
	glEnable(GL_COLOR_MATERIAL);
}

void handleResize(int w, int h) {
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(45.0, (float)w / (float)h, 1.0, 200.0);
}

void drawScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
	
	glTranslatef(0.0f, 1.0f, -6.0f);
	
	GLfloat ambientLight[] = {0.2f, 0.2f, 0.2f, 1.0f};
	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
	
	GLfloat directedLight[] = {0.7f, 0.7f, 0.7f, 1.0f};
	GLfloat directedLightPos[] = {-10.0f, 15.0f, 20.0f, 0.0f};
	glLightfv(GL_LIGHT0, GL_DIFFUSE, directedLight);
	glLightfv(GL_LIGHT0, GL_POSITION, directedLightPos);
	
	
	loadTextures("grass.jpg", 0);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[0]);
	
	//Bottom
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	//glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	
	glNormal3f(0.0, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-2.5f, -2.5f, 2.5f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(2.5f, -2.5f, 2.5f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(2.5f, -2.5f, -2.5f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-2.5f, -2.5f, -2.5f);
	
	glEnd();
	
	glDisable(GL_TEXTURE_2D);
	
	loadTextures("mont.jpg", 1);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[1]);
	
////////////////////////////////////////////////////
//Se dibuja la imagen de las montañas en cada lado
////////////////////////////////////////////////////
	//Back
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	
	glNormal3f(0.0f, 0.0f, 2.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-2.5f, -2.5f, -2.5f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-2.5f, 0.6f, -2.5f);
	glTexCoord2f(2.0f, 1.0f);
	glVertex3f(2.5f, 0.6f, -2.5f);
	glTexCoord2f(2.0f, 0.0f);
	glVertex3f(2.5f, -2.5f, -2.5f);
	
	glEnd();
	
	//Left
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-2.5f, -2.5f, 2.5f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-2.5f, 0.6f, 2.5f);
	glTexCoord2f(2.0f, 1.0f);
	glVertex3f(-2.5f, 0.6f, -2.5f);
	glTexCoord2f(2.0f, 0.0f);
	glVertex3f(-2.5f, -2.5f, -2.5f);
	
	glEnd();
	
	//Right
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	
	glNormal3f(-1.0f, 0.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(2.5f, -2.5f, -2.5f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(2.5f, 0.6f, -2.5f);
	glTexCoord2f(2.0f, 1.0f);
	glVertex3f(2.5f, 0.6f, 2.5f);
	glTexCoord2f(2.0f, 0.0f);
	glVertex3f(2.5f, -2.5f, 2.5f);
	
	glEnd();
	
////////////////////////////////////////////////////
//Se dibuja el cielo
////////////////////////////////////////////////////
	//Top
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_TEXTURE_2D);
	loadTextures("cielo.jpg", 2);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[2]);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glColor3f(1.0f, 1.0f, 1.0f);
	glBegin(GL_QUADS);
	
	glNormal3f(0.0, 1.0f, 0.0f);
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-2.5f, 0.6f, 2.5f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(2.5f, 0.6f, 2.5f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(2.5f, 0.6f, -2.5f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-2.5f, 0.6f, -2.5f);
	
	glEnd();
	
	glDisable(GL_TEXTURE_2D);
	
////////////////////////////////////////////////////
//Se dibuja 6 cuadrados para el cubo y se une la
//textura a cada cara
////////////////////////////////////////////////////

	//Cubo
	
	glPushMatrix();
	
	glTranslatef(0.0f, -1.0f, 0.0f);
	glRotatef(angx, 1.0, 0.0, 0.0);
	glRotatef(angy, 0.0, 1.0, 0.0);
	
	//delante
	glEnable(GL_TEXTURE_2D);
	loadTextures("madera.jpg", 3);
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	glBegin(GL_QUADS);
	
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-0.8f, -0.8f, -0.8f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-0.8f, 0.8f, -0.8f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(0.8f, 0.8f, -0.8f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(0.8f, -0.8f, -0.8f);
	
	glEnd();
	
	glDisable(GL_TEXTURE_2D);
	//atras
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	glBegin(GL_QUADS);
	
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-0.8f, -0.8f, 0.8f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-0.8f, 0.8f, 0.8f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(0.8f, 0.8f, 0.8f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(0.8f, -0.8f, 0.8f);
	
	glEnd();
	
	glDisable(GL_TEXTURE_2D);
	//derecha
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	glBegin(GL_QUADS);
	
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(0.8f, -0.8f, -0.8f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(0.8f, 0.8f, -0.8f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(0.8f, 0.8f, 0.8f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(0.8f, -0.8f, 0.8f);
	
	glEnd();
	
	glDisable(GL_TEXTURE_2D);
	//izquierda
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	glBegin(GL_QUADS);
	
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-0.8f, -0.8f, 0.8f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-0.8f, 0.8f, 0.8f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-0.8f, 0.8f, -0.8f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-0.8f, -0.8f, -0.8f);
	
	glEnd();
	
	glDisable(GL_TEXTURE_2D);
	//arriba
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	glBegin(GL_QUADS);
	
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(-0.8f, 0.8f, 0.8f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(-0.8f, 0.8f, -0.8f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(0.8f, 0.8f, -0.8f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(0.8f, 0.8f, 0.8f);
	
	glEnd();
	
	glDisable(GL_TEXTURE_2D);
	//abajo
	glEnable(GL_TEXTURE_2D);
	glBindTexture(GL_TEXTURE_2D, texID[3]);
	
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glColor3f(1.0f, 1.0f, 1.0f);
	
	glBegin(GL_QUADS);
	
	glTexCoord2f(0.0f, 0.0f);
	glVertex3f(0.8f, -0.8f, -0.8f);
	glTexCoord2f(1.0f, 0.0f);
	glVertex3f(0.8f, -0.8f, 0.8f);
	glTexCoord2f(1.0f, 1.0f);
	glVertex3f(-0.8f, -0.8f, 0.8f);
	glTexCoord2f(0.0f, 1.0f);
	glVertex3f(-0.8f, -0.8f, -0.8f);
	
	glEnd();
	
	glDisable(GL_TEXTURE_2D);
	
	glPopMatrix();
	
	glutSwapBuffers();
}

int main(int argc, char** argv) {
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(400, 400);
	
	glutCreateWindow("CC322-PCL3");
	initRendering();
	
	glutDisplayFunc(drawScene);
	glutKeyboardFunc(handleKeypress);
	glutReshapeFunc(handleResize);
	
	glutMainLoop();
	return 0;
}









