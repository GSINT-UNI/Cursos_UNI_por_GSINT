
class Master {
    private TCPServer server;
    
}