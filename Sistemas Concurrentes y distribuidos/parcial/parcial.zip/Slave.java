import java.util.Scanner;

class Slave {
    private TCPClient client;
    private ImageIO img;

}