
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;



public class CSVhandler {
	private static Scanner x;

	public static void main(String[] args) {
		String filepath = "D:\\ConFe\\src\\nuevopackage\\cuentas.csv";
		String editTerm = "99863";
		String newSaldo = "5600";
		//String newAge = "82";
	    Dictionary<String, String> d = new Hashtable<String, String>(); 
	    //d.put(1,"Passion");
		/*editRecord(filepath,"4","4","4500");  // Ruta, cuenta a modificar, cuenta a modificar XD, cantidad a modificar
		editRecord(filepath,"1","1",newSaldo);*/
		editRecord(filepath,"10","10","500");
		editRecord(filepath,"12","12","1500");
	    try {
			x = new Scanner(new File(filepath));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		x.useDelimiter("[;\n]");
		String ID="";
		String saldo = "";
		while(x.hasNext()) {
			ID = x.next();
			saldo = x.next();
			d.put(ID, saldo);
			
		}
		
		Scanner in = new Scanner(System.in);
		String consulta = " ";
		do{
			System.out.println("Consulte: ");
			consulta = in.nextLine();
			System.out.println(d.get(consulta));

		}while(!consulta.equals("nada"));
		in.close();
		//insertRecord(filepath,newID,newName,newAge);

		
	}
	
	public static void insertRecord(String ruta, String newID, String newName, String newAge) {
		String tempFile = "/home/gusfraba/Documentos/temp.csv";
		File oldFile = new File(ruta);
		File newFile = new File(tempFile);
		String ID="";String name = ""; String age= "";

		try {
			FileWriter fw = new FileWriter(tempFile,true);
			BufferedWriter bv = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bv);
			x = new Scanner(new File(ruta));
			x.useDelimiter("[;\n]");
			/*
			while(x.hasNext()) {
				ID = x.next();
				name = x.next();
				age = x.next();

					pw.println(ID + "," + name + "," + age);
				
				
			}*/
			pw.println(newID + ";" + newName + ","+ newAge);

			
			x.close();
			pw.flush();
			pw.close();
			oldFile.delete();
			File dump = new File(ruta);
			newFile.renameTo(dump);
		}
		catch(Exception e){
			System.out.println("Error...");
		}
	}
	
	public static void editRecord(String ruta,String editTerm, String newID, String newName) {
		String tempFile = "D:\\ConFe\\src\\nuevopackage\\tmp.csv";
		File oldFile = new File(ruta);
		File newFile = new File(tempFile);
		String ID="";String name = "";
		try {
			FileWriter fw = new FileWriter(tempFile,true);
			BufferedWriter bv = new BufferedWriter(fw);
			PrintWriter pw = new PrintWriter(bv);
			x = new Scanner(new File(ruta));
			x.useDelimiter("[;\n]");
			
			while(x.hasNext()) {
				ID = x.next();
				name = x.next().replaceAll("(\\r|\\n)", "");
				if (ID.equals(editTerm)) {
					pw.println(newID + ";" + newName);
				}
				else {
					pw.println(ID + ";" + name);
				}
				
			}
			x.close();
			pw.flush();
			pw.close();			
			System.out.println("deleteo: " + oldFile.delete());
			File dump = new File(ruta);
			System.out.println("renombrado: " + newFile.renameTo(dump) );
		}
		catch(Exception e){
			System.out.println("Error...");
		}
	}

}
