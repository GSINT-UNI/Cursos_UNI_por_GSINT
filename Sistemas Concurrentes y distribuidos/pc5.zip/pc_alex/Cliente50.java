
import java.util.Random;
import java.util.concurrent.TimeUnit;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


class Cliente50 {

    public int sum[] = new int[40];
    TCPClient50 mTcpClient;
    Scanner sc;
    
    public static void main(String[] args) throws InterruptedException {
        Cliente50 objcli = new Cliente50();
        objcli.iniciar();
    }

    void iniciar() throws InterruptedException {
        new Thread(
                new Runnable() {

            @Override
            public void run() {
                 //mTcpClient = new TCPClient50("127.0.0.1",
              mTcpClient = new TCPClient50("192.168.88.101",
                        new TCPClient50.OnMessageReceived() {
                    @Override
                    public void messageReceived(String message) {
                        ClienteRecibe(message);
                    }
                }
                );
                mTcpClient.run();
            }
        }
        ).start();
        //---------------------------

        String salir = "n";
        sc = new Scanner(System.in);
        System.out.println("Cliente bandera 01");
         ClienteEnvia("OK");
        while (!salir.equals("s")) {
            salir = sc.nextLine();
            System.out.println("Enviando...");
            ClienteEnvia(salir);
        }/*
        for(int i = 10 ; i<200 ; i++){
        	try {
				TimeUnit.SECONDS.sleep(1);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        	ClienteEnvia("envio_a "+String.valueOf(i));
        }*/
        System.out.println("Cliente bandera 02");

    }
    int i=0;
    void ClienteRecibe(String llego) {
        i++;
        System.out.println("CLINTE50 Llego el mensaje"+i+" :" + llego);
        
   }

    void ClienteEnvia(String envia) throws InterruptedException {
       Random r = new  Random();
       int x;
       String m = "";
       if (envia.trim().contains("OK")) {
           mTcpClient.sendMessage(envia);      
       }else{
       int cuenta1,cuenta2,saldo;
       if (mTcpClient != null) {
            for (int i = 0; i <5000 ; i++) {
                
                 try{ Thread.sleep(1);} catch (InterruptedException ex) {
                    Logger.getLogger(Cliente50.class.getName()).log(Level.SEVERE, null, ex);
                }
                mTcpClient.sendMessage(envia);
                x=r.nextInt(100);
                if(x<10){
                    cuenta1 = r.nextInt(10000);
                    cuenta2 = r.nextInt(10000);
                    saldo = r.nextInt(500);
                    mTcpClient.sendMessage("A-"+cuenta1+"-"+cuenta2+"-"+saldo);
                    System.out.println("A-"+cuenta1+"-"+cuenta2+"-"+saldo);
                    mTcpClient.sendMessage("L-"+cuenta1);
                  //  System.out.println("L-"+cuenta1);
                    mTcpClient.sendMessage("L-"+cuenta2);
                  //  System.out.println("L-"+cuenta2);
                }
                else{
                    cuenta1 = r.nextInt(10000);
                    mTcpClient.sendMessage("L-"+cuenta1);
                    System.out.println("L-"+cuenta1);
                }                     
                //mTcpClient.sendMessage("");

            }
        }
       }
        
       // mTcpClient.sendMessage(envia);      
    }

    double funcion(int fin) {
        double sum = 0;
        for (int j = 0; j <= fin; j++) {
            sum = sum + Math.sin(j * Math.random());
        }
        return sum;
    }

    void procesar(int a, int b) throws InterruptedException {
        int N = (b - a);//14;
        int H = 12;//luego aumentar
        int d = (int) ((N) / H);
        Thread todos[] = new Thread[40];
        for (int i = 0; i < (H - 1); i++) {
            System.out.println("a:" + (i * d + a) + "b" + (i * d + d + a) + " i" + i);
            todos[i] = new tarea0101((i * d + a), (i * d + d + a), i);
            todos[i].start();
        }
        System.out.println("a" + ((d * (H - 1)) + a) + "b" + (b + 1) + " i" + (H - 1));
        Thread Hilo;
        todos[H - 1] = new tarea0101(((d * (H - 1)) + a), (b + 1), H - 1);
        todos[H - 1].start();
        for (int i = 0; i <= (H - 1); i++) {//AQUI AQUI VER <=
            try {
                todos[i].join();
            } catch (InterruptedException ex) {
                System.out.println("error" + ex);
            }
        }
        int sumatotal = 0;
        for (int i = 0; i < H; i++) {
            sumatotal = sumatotal + sum[i];
        }
        System.out.println("SUMA TOTAL____:" + sumatotal);
        ClienteEnvia("rpta " + sumatotal);
    }

    public class tarea0101 extends Thread {

        public int max, min, id;

        tarea0101(int min_, int max_, int id_) {
            max = max_;
            min = min_;
            id = id_;

        }

        public void run() {
            int suma = 0;
            for (int i = min; i < max; i++) {
                suma = suma + i;
            }
            sum[id] = suma;
            System.out.println(" min:" + min + " max:" + (max - 1) + " id:" + id + " suma:" + suma);
        }
    }

}
