import java.util.Scanner;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;


class Nodo50 {
    private static Scanner x;
    public int sum[] = new int[40];
    TCPNodo50 mTcpNodo;
    String filepath = "";
    Scanner sc;
    int idnodo;
    private static Dictionary<String, String> tabla = new Hashtable<String, String>(); 

    public static void main(String[] args) {
	    //Actualizar();
		System.out.println("Indexad... ejemplo: d.get(8)= "+tabla.get("8"));
		System.out.println("Indexad... ejemplo: d.get(8)= "+tabla.get("1"));
        Nodo50 objcli = new Nodo50();
        objcli.iniciar();
    }

    void iniciar() {
        new Thread(
                new Runnable() {

            @Override
            public void run() {
                //mTcpNodo = new TCPNodo50("127.0.0.1",
                mTcpNodo = new TCPNodo50("192.168.88.101",
                        new TCPNodo50.OnMessageReceived() {
                    @Override
                    public void messageReceived(String message) {
                    	NodoRecibe(message);
                    }
                }
                );
                mTcpNodo.run();
            }
        }
        ).start();
        //---------------------------

        String salir = "n";
        sc = new Scanner(System.in);
        System.out.println("Nodo bandera 01");
        NodoEnvia("Nodo");
        while (!salir.equals("s")) {
            salir = sc.nextLine();
            NodoEnvia(salir);
        }
        System.out.println("Nodo bandera 02");

    }
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String ANSI_GREEN = "\u001B[31m";
    void NodoRecibe(String llego) {
        
        
        if(llego.trim().contains("SUMA")){
            
            int sum = 0 ;
            for (int i = 1; i < 10000 + 1; i++) {
                sum=sum+Integer.valueOf(tabla.get(i+""));               
            }
            
            System.out.println(ANSI_GREEN +"Money Total : " + sum + ANSI_RESET);
            
        }else{   
        
        System.out.println("Nodo 50 recibe el mensaje : " + llego);
        //asignamos el idnodo
        if (llego.trim().contains("ID")) {
            String idn[] = llego.split(",");
            idnodo = Integer.valueOf(idn[1]);
            System.out.println("Soy el nodo " + idnodo + " :V");
            filepath = "./cuentas"+idnodo+".csv";
            System.out.println("Mi base de datos es : " + filepath);
        }else
        
        {Actualizar();
        String csvFilePath =  filepath;
        System.out.println("CLINTE50 El mensaje::" + llego);
        //ClienteEnvia("Soy el cliente y recibi " +llego);
        System.out.println("Me pondre a calcular con*" + llego + "*");
        String arrString[] = llego.split("-");
        int idSolicitud = Integer.parseInt(arrString[0]);
        String letraTransaccion = arrString[1];
        String id_cuenta1 = arrString[2];
        
        //int idSolicitud = Integer.parseInt(arrString[3]);
        if (letraTransaccion.equals("L")) {
            System.out.println("cuenta: " + idSolicitud + " consulta: " + letraTransaccion + " id_a_consultar: " + id_cuenta1);
            System.out.println("El monto es " + tabla.get(id_cuenta1).replaceAll("(\\r|\\n)", "") + " vale");
            System.out.println("Enviare: " + "monto" + " " + tabla.get(id_cuenta1) + " " + String.valueOf(idSolicitud));
            NodoEnvia(("monto" + " " + tabla.get(id_cuenta1) + " " + String.valueOf(idSolicitud)).replaceAll("(\\r|\\n)", ""));
        }
        if (letraTransaccion.equals("A")) {
            String id_cuenta2 = arrString[3];
            String pago = arrString[4];
            if (Integer.parseInt(pago) < Integer.parseInt(tabla.get(id_cuenta1))) {
                editRecord(csvFilePath, id_cuenta1, id_cuenta1, Integer.toString(Integer.parseInt(tabla.get(id_cuenta1).replaceAll("(\\r|\\n)", "")) - Integer.parseInt(pago)));
                Actualizar();
                editRecord(csvFilePath, id_cuenta2, id_cuenta2, Integer.toString(Integer.parseInt(tabla.get(id_cuenta2).replaceAll("(\\r|\\n)", "")) + Integer.parseInt(pago)));
                Actualizar();
                Replicar(String.valueOf(idSolicitud), id_cuenta1, id_cuenta2, pago);
                System.out.println("El monto de transferencia es " + pago + " vale");
                System.out.println("Enviare: " + "Transferencia satisfactoria" + " " + "ID: " + " " + String.valueOf(idSolicitud));
                NodoEnvia(("relleno Transferencia_satisfactoria." + " " + " " + String.valueOf(idSolicitud)).replaceAll("(\\r|\\n)", ""));
            } else {
                System.out.println("Fondos insuficientes");
                NodoEnvia(("relleno Transferencia_denegada:_Fondos_insuficientes." + " " + " " + String.valueOf(idSolicitud)).replaceAll("(\\r|\\n)", ""));
            }

        }
        if (letraTransaccion.equals("R")) {
            String id_cuenta2 = arrString[3];
            String pago = arrString[4];
            editRecord(csvFilePath, id_cuenta1, id_cuenta1, Integer.toString(Integer.parseInt(tabla.get(id_cuenta1).replaceAll("(\\r|\\n)", "")) - Integer.parseInt(pago)));
            Actualizar();
            editRecord(csvFilePath, id_cuenta2, id_cuenta2, Integer.toString(Integer.parseInt(tabla.get(id_cuenta2).replaceAll("(\\r|\\n)", "")) + Integer.parseInt(pago)));
            Actualizar();
            System.out.println("Replicaion terminada por la solicitud: " + idSolicitud);
            mTcpNodo.sendMessage("Replica END");
            
        }
        }
        //int sum = 0;
      /*  for(int i =1 ; i<= Integer.valueOf(llego) ; i++) {
        	sum+=i;
        }*/
        //System.out.println("Voy a responder "+llego);
        //procesar(1,resultado,idSolicitud);
        }
    }

    void NodoEnvia(String envia) {
        if (mTcpNodo != null) {
            mTcpNodo.sendMessage(envia);
        }
    }

    void Replicar(String idSolicitud, String idCuenta1, String idCuenta2, String pago) {
        System.out.println("Enviando mesaje de replica");
        NodoEnvia(this.mTcpNodo.socket.getLocalPort() + "-" + idSolicitud + "-R-" + idCuenta1 + "-" + idCuenta2 + "-" + pago);
    }
    
    double funcion(int fin) {
        double sum = 0;
        for (int j = 0; j <= fin; j++) {
            sum = sum + Math.sin(j * Math.random());
        }
        return sum;
    }

    void procesar(int a, int b, int id) {
        int N = (b - a);//14;
        int H = 12;//luego aumentar
        int d = (int) ((N) / H);
        Thread todos[] = new Thread[40];
        for (int i = 0; i < (H - 1); i++) {
            System.out.println("a:" + (i * d + a) + "b" + (i * d + d + a) + " i" + i);
            todos[i] = new tarea0101((i * d + a), (i * d + d + a), i);
            todos[i].start();
        }
        System.out.println("a" + ((d * (H - 1)) + a) + "b" + (b + 1) + " i" + (H - 1));
        Thread Hilo;
        todos[H - 1] = new tarea0101(((d * (H - 1)) + a), (b + 1), H - 1);
        todos[H - 1].start();
        for (int i = 0; i <= (H - 1); i++) {//AQUI AQUI VER <=
            try {
                todos[i].join();
            } catch (InterruptedException ex) {
                System.out.println("error" + ex);
            }
        }
        int sumatotal = 0;
        for (int i = 0; i < H; i++) {
            sumatotal = sumatotal + sum[i];
        }
        System.out.println("SUMA TOTAL____:" + sumatotal);
        //NodoEnvia("rpta " + sumatotal);
        NodoEnvia("respondo"+" "+id+" "+sumatotal);

    }

    public class tarea0101 extends Thread {

        public int max, min, id;

        tarea0101(int min_, int max_, int id_) {
            max = max_;
            min = min_;
            id = id_;

        }

        public void run() {
            int suma = 0;
            for (int i = min; i < max; i++) {
                suma = suma + i;
            }
            sum[id] = suma;
            System.out.println(" min:" + min + " max:" + (max - 1) + " id:" + id + " suma:" + suma);
        }
    }
    
    public void editRecord(String ruta, String editTerm, String newID, String newName) {
        String tempFilePath = ".\\tmp"+idnodo+".csv";
        Scanner sca;
        File oldFile = new File(ruta);
        File newFile = new File(tempFilePath);
        String ID;
        String name;
        try {
            FileWriter fw = new FileWriter(tempFilePath, true);
            BufferedWriter bv = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bv);
            sca = new Scanner(new File(ruta));
            sca.useDelimiter("[;\n]");

            while (sca.hasNext()) {
                ID = sca.next();
                name = sca.next().replaceAll("(\\r|\\n)", "");
                if (ID.equals(editTerm)) {
                    pw.println(newID + ";" + newName);
                } else {
                    pw.println(ID + ";" + name);
                }

            }
            sca.close();
            //Thread.sleep(1000);
            pw.flush();
            pw.close();

            System.out.println("deleteo: " + oldFile.delete());
            File dump = new File(ruta);
            System.out.println("renombrado: " + newFile.renameTo(dump));
        } catch (Exception e) {
            System.out.println("Error...");
        }
    }
    
    public  void Actualizar() {
        try {
            x = new Scanner(new File( filepath));
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        x.useDelimiter("[;\n]");
        String ID;
        String saldo;
        while (x.hasNext()) {
            ID = x.next();
            saldo = x.next().replaceAll("(\\r|\\n)", "");
            tabla.put(ID, saldo);
        }
        x.close();
    }

}
