
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;
public class Servidor50 {
    TCPServer50 mTcpServer;
    Scanner sc;
    Queue<String> cola=new LinkedList();
    int numeroNodos = 18 ;
    //TCPServerThread50[] sendcliente = new TCPServerThread50[10];
    //TCPServerThread50[] sendnodo = new TCPServerThread50[10];
    
    public static void main(String[] args) {
        Servidor50 objser = new Servidor50();
        objser.iniciar();
    }

    void iniciar() {
        new Thread(
                new Runnable() {

            @Override
            public void run() {
               
                mTcpServer = new TCPServer50(
                        new TCPServer50.OnMessageReceived() {
                    @Override
                    public void messageReceived(String message) {
                    	synchronized(this){
                            ServidorRecibe(message);
                    	}

                    }
                }
                );
                mTcpServer.run();
                
            }
        }
        ).start();
        //-----------------
        String salir = "n";
        sc = new Scanner(System.in);
        System.out.println("Servidor bandera 01");
        while (!salir.equals("s")) {
            salir = sc.nextLine();
            ServidorEnvia(salir);
        }
        System.out.println("Servidor bandera 02");

    }
    int contarcliente = 0;
    int rptacli[] = new int[20];
    int sumclient = 0;
    boolean mensajeCliente = true;
    boolean bloqueado = false ;
    int contadorReplicasNodos = 0;
    void ServidorRecibe(String llego) {
        System.out.println("SERVIDOR40 -> Recibio el mensaje : " + llego);
        //System.out.println("Mi cola : " + cola);
        //si llega ok de un cliente, se manda id a los nodos
        if (llego.trim().contains("OK") && mensajeCliente) {
             mTcpServer.sendID("Enviando ids a los nodos");
             //solo se debe ejecutar una vez
             mensajeCliente=!mensajeCliente;
         }
        else if(llego.trim().contains("END") ){
            contadorReplicasNodos++;
            if(contadorReplicasNodos<1){
                mTcpServer.sendMessageNodosSuma("SUMA");
                bloqueado=false;
                contadorReplicasNodos=0;
                 
            }
        }
        else if(llego.trim().contains("R") ){
            ServidorEnvia(llego);
        }
        else{   
        cola.add(llego);
        System.out.println("Mi cola : " + cola);
        if (true) {
            while(cola.peek()!=null){
                 String message = cola.poll();
                 if(message.trim().contains("A")){
                     bloqueado=true;
                     ServidorEnvia(message); 
                     break;
                 }else{
                     ServidorEnvia(message);
                 }     
            }
        } 
        }
      }
    
    void ServidorEnvia(String envia) {//El servidor tiene texto de envio
        if (envia != null) {
            System.out.println("Soy Server y envio: " + envia);
            if (envia.indexOf("monto")!=-1 || envia.indexOf("Transferencia")!=-1) {
                System.out.println("SI TIENE ENVIO, fue un nodo!!!");
                //String arrayString[] = envia.split("\\s+");
                //int id = Integer.parseInt(arrayString[1]);

                if (mTcpServer != null) {
                    mTcpServer.sendMessageTCPServerCliente(envia);
                }
            } 
            else  if (envia.indexOf("L")!=-1 || envia.indexOf("A")!=-1) {
                System.out.println("SI TIENE ENVIO, fue un cliente!!!");
                //String arrayString[] = envia.split("\\s+");
                if (mTcpServer != null) {
                    mTcpServer.sendMessageTCPServer(envia);
                }
            }
            else if (envia.indexOf("R")!=-1){
                System.out.println("SI TIENE ENVIO, fue un nodo!!!");
                if (mTcpServer != null)
                    mTcpServer.sendMessageTCPServerNodos(envia);
            }
            else {
                System.out.println("NO TIENE ENVIO!!!");
            }
        }
    }
}
