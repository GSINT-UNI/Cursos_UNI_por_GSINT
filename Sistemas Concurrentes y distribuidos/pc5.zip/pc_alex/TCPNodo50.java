
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;


public class TCPNodo50 {

    private String servermsj;
    public  String SERVERIP;
    public static final int SERVERPORT = 4444;
    private OnMessageReceived mMessageListener = null;
    private boolean mRun = false;
    Socket socket;

    PrintWriter out;
    BufferedReader in;

    public TCPNodo50(String ip,OnMessageReceived listener) {
        SERVERIP = ip;
        mMessageListener = listener;
    } 
    public void sendMessage(String message){
        if (out != null && !out.checkError()) {
            out.println(message);
            out.flush();
        }
    }
    public void stopNodo(){
        mRun = false;
    }
    public void run() {
        mRun = true;
        try {
            InetAddress serverAddr = InetAddress.getByName(SERVERIP);
            System.out.println("TCP Nodo"+ "C: Conectando...");
            socket = new Socket(serverAddr, SERVERPORT);
            try {
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);
                System.out.println("TCP Nodo"+ "C: Sent.");
                System.out.println("TCP Nodo"+ "C: Done.");
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                while (mRun) {
                    servermsj = in.readLine();
                    if (servermsj != null && mMessageListener != null) {
                        mMessageListener.messageReceived(servermsj);
                    }
                    servermsj = null;
                }
            } catch (Exception e) {
                System.out.println("TCP"+ "S: Error"+e);

            } finally {
                socket.close();
            }
        } catch (Exception e) {
            System.out.println("TCP"+ "C: Error"+ e);
        }
    }
    public interface OnMessageReceived {
        public void messageReceived(String message);
    }
}