
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;


import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Arrays; 

public class TCPServer50 {
    private String message;
    public int jugada=0;
    int nnodos = 18;
    int nrcli = 0;
    int nrnod = 0;
    int pesos[] = {3,8,2};
    public static final int SERVERPORT = 4444;
    private OnMessageReceived messageListener = null;
    private boolean running = false;
    TCPServerThread50[] sendclis = new TCPServerThread50[20];
    TCPServerThread51[] sendnods = new TCPServerThread51[20];
    
    PrintWriter mOut;
    BufferedReader in;
    
    ServerSocket serverSocket;

    
    
    //el constructor pide una interface OnMessageReceived
    public TCPServer50(OnMessageReceived messageListener/*, String tipo_*/) {
        this.messageListener = messageListener;
        //this.tipo = tipo_;
    }
    
    public OnMessageReceived getMessageListener(){/////¨
        return this.messageListener;
    }
    
    public void sendMessageTCPServer(String message){
    	this.jugada++;
    	if(this.jugada%this.nrnod==0)
    		sendnods[this.nrnod].sendMessage(message);
    	else
    		sendnods[this.jugada%this.nrnod].sendMessage(message);
        System.out.println("ENVIANDO A JUGADOR " + (this.jugada)+" el numero "+message);
        
    
    }
    
    public void sendMessageTCPServerCliente(String mensasje) {   // a que cliente enviarle
    	System.out.println("Mensaje: "+mensasje);
        String arrString[] = mensasje.split("\\s+");
        String resultado = arrString[1];
        System.out.println("resultado: "+resultado);
        int id = Integer.parseInt(arrString[2]);
        System.out.println("id: "+id);

        sendclis[id].sendMessage("respondo "+resultado);
            //System.out.println("ENVIANDO A JUGADOR " + (i));
        }   
    	
    
    public void sendMessageTCPServerNodo(String message) {   // a que nodo enviarle
    	System.out.println("Mensaje: "+message);
    	this.jugada++;
    	/*if(this.jugada%this.nrnod==0)
    		sendnods[this.nrnod].sendMessage(message);
    	else
    		sendnods[this.jugada%this.nrnod].sendMessage(message);
        System.out.println("ENVIANDO A JUGADOR " + (this.jugada)+" el numero "+message);
        */
        //int[] orden= {3,8,2};
        int[] indices = {0,2,3,1};
        //Arrays.sort(pesos);
        if(/*pesos[indices[jugada%3]] == orden[indices[jugada%3]] &&*/ this.jugada%this.nrnod==0) 
        	sendnods[indices[this.nrnod]].sendMessage(message);
    	else
    		sendnods[indices[this.jugada%this.nrnod]].sendMessage(message);
        System.out.println("ENVIANDO A JUGADOR " + (this.jugada)+" el numero "+message);      
        
        
        
        
    }
    public void sendID(String message){   

        for (int i = 1; i < nnodos+1; i++) {
            System.out.println("Enviando al nodo "+i+" el mensaje ID,"+nrnod);
            sendnods[i].sendMessage("ID,"+i );
        }
       // System.out.println("ENVIANDO A NODO " + (id));
    }
    
     public void sendMessageNodosSuma(String message){   

        for (int i = 1; i < nnodos+1; i++) {
            System.out.println("Enviando al nodo "+i+" el mensaje SUMA");
            sendnods[i].sendMessage(message);
        }
       // System.out.println("ENVIANDO A NODO " + (id));
    }  
     
    public void sendMessageTCPServerNodos(String message) {   // todos
    	String socketNodeSourceStr = message.substring(0, message.indexOf("-"));
        message = message.substring(message.indexOf("-")+1);
        System.out.println("Socket fuente: " + socketNodeSourceStr);
        System.out.println("Mensaje: " + message);
    	
        for (int i = 1; i<= nrnod; i++) {
            System.out.println("Socket " + i + ": " + String.valueOf(sendnods[i].getClient().getPort()));
            if( !String.valueOf(sendnods[i].getClient().getPort()).contains(socketNodeSourceStr)){
                System.out.println("Enviando al nodo: " + i);
                sendnods[i].sendMessage(message);
            }
        }
        
        
    }
    
    public void sendMessageTCPServerRango(String message, int Rango){    
        int d = (int) ((Rango) / nrnod);
        for (int i = 1; i < nrnod; i++) {
            //System.out.println("i:" + ((i-1) * d + 1) + "(i+d):" + ((i-1) * d + d));        	
            sendclis[i].sendMessage("evalua " + ((i-1) * d + 1) + " " + ((i-1) * d + d));
            System.out.println("ENVIANDO A JUGADOR " + (i));
        }
        //System.out.println("i:" + ((d * (nrcli - 1))+1) + "(N):" + (Rango));  
        sendclis[nrnod].sendMessage("evalua " + ((d * (nrnod - 1))+1) + " " + (Rango));
        System.out.println("ENVIANDO A JUGADOR " + (nrnod));
    }    

    public void run(){
        running = true;
        try{
            System.out.println("TCP Server"+"S : Connecting...");
            serverSocket = new ServerSocket(SERVERPORT);

            for (int i = 1; i < nnodos+1; i++) { //ACEPTANDO NODOS ESCLAVOS (ACEPTA 4)
            	Socket client = serverSocket.accept();
                System.out.println("TCP Server"+"S: Receiving...");
                nrnod++;

                File origin = new File("./cuentas.csv");
                File destination = new File("./cuentas"+nrnod+".csv");
                
                InputStream in = new FileInputStream(origin);
                OutputStream out = new FileOutputStream(destination);
                byte[] buf = new byte[1024];
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                in.close();
                out.close();
                System.out.println("Nodo " + nrnod+ " conectado ");
                sendnods[nrnod] = new TCPServerThread51(client,this,nrnod,sendnods);
               
               // sendnods[nrnod].sendMessage("ID,"+ nrnod );
                Thread t = new Thread(sendnods[nrnod]);                
                t.start();
                //this.sendID(nrnod, "ID,"+ nrnod );
                System.out.println("TOTAL :    "+ nrnod+" nodos conectados");
            }
            
            for (int i = 1; i < 10; i++) { //ACEPTANDO CLIENTES (ACEPTA 4)
            	Socket client = serverSocket.accept();
                System.out.println("TCP Server"+"S: Receiving...");
                nrcli++;
                System.out.println("Engendrado " + nrcli);
                sendclis[nrcli] = new TCPServerThread50(client,this,nrcli,sendclis);
                Thread t = new Thread(sendclis[nrcli]);
                t.start();
                System.out.println("Nuevo cliente conectado:"+ nrcli+" clientes conectados");
            }
            
        }catch( Exception e){
            System.out.println("Error"+e.getMessage());
        }finally{

        }
    }
  
    
    public  TCPServerThread50[] getClients(){
        return sendclis;
    } 

    public  interface OnMessageReceived {
        public void messageReceived(String message);
    }
}
