/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */

import java.util.LinkedList;
import java.util.Queue;

public class prueba {    
    public static void main(String[] args) {
        /*Creamos la Cola Indicando el tipo de dato*/
        Queue<Integer> cola=new LinkedList();
        /*Insertamos datos*/
            cola.offer(3);
            cola.add(14);
            cola.offer(12);
            cola.add(7);
            cola.offer(10);
        /*Impresion de la Cola llena con los datos*/
        System.out.println("Cola llena: " + cola);
        /*Estructura repetitiva para desencolar*/
        int x;
        while(cola.peek()!=null){//Desencolamos y el valor se compara con null
            x = cola.poll();
            System.out.println(x);//Muestra el nuevo Frente
        }
        System.out.println("Cola llena: " + cola);
        
        /*Muestra null debido a que la cola ya esta vacia*/
        System.out.println(cola.peek());     
    }

}
